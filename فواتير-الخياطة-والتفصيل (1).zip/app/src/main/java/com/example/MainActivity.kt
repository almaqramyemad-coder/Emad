package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.components.InvoiceReceiptDialog
import com.example.ui.screens.*
import com.example.ui.theme.TailorInvoiceTheme

enum class Screen(val title: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Default.Home),
    INVOICES("الفواتير", Icons.Default.ReceiptLong),
    CREATE_INVOICE("فاتورة جديدة", Icons.Default.AddCircle),
    CUSTOMERS("العملاء والمقاسات", Icons.Default.Group),
    VOUCHERS("السندات", Icons.Default.Receipt),
    REPORTS("التقارير", Icons.Default.BarChart),
    DELIVERIES("التسليم", Icons.Default.LocalShipping),
    SETTINGS("الإعدادات", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TailorInvoiceTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(
    viewModel: TailorViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(Screen.HOME) }

    val customers by viewModel.customers.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val vouchers by viewModel.vouchers.collectAsState()
    val filteredOrders by viewModel.filteredOrders.collectAsState()
    val filteredCustomers by viewModel.filteredCustomers.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val shopSettings by viewModel.shopSettings.collectAsState()
    val selectedInvoice by viewModel.selectedInvoice.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentScreen != Screen.CREATE_INVOICE) {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = shopSettings.shopName,
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    actions = {
                        IconButton(
                            onClick = { currentScreen = Screen.SETTINGS },
                            modifier = Modifier.testTag("topbar_settings_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Screen.entries.forEach { screen ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { currentScreen = screen },
                        icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(
                    viewModel = viewModel,
                    orders = orders,
                    onNavigateToCreateInvoice = { currentScreen = Screen.CREATE_INVOICE },
                    onNavigateToDeliveries = { currentScreen = Screen.DELIVERIES },
                    onNavigateToCustomers = { currentScreen = Screen.CUSTOMERS },
                    onSelectInvoice = { viewModel.selectInvoiceForReceipt(it) }
                )
                Screen.INVOICES -> InvoicesScreen(
                    viewModel = viewModel,
                    orders = filteredOrders,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    onNavigateToCreateInvoice = { currentScreen = Screen.CREATE_INVOICE },
                    onSelectInvoice = { viewModel.selectInvoiceForReceipt(it) }
                )
                Screen.CREATE_INVOICE -> CreateInvoiceScreen(
                    viewModel = viewModel,
                    customers = customers,
                    onInvoiceSaved = {
                        currentScreen = Screen.INVOICES
                    },
                    onBack = { currentScreen = Screen.HOME }
                )
                Screen.CUSTOMERS -> CustomersScreen(
                    viewModel = viewModel,
                    customers = filteredCustomers,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    onNavigateToCreateInvoice = { currentScreen = Screen.CREATE_INVOICE }
                )
                Screen.VOUCHERS -> VouchersScreen(
                    viewModel = viewModel,
                    vouchers = vouchers,
                    customers = customers
                )
                Screen.REPORTS -> ReportsScreen(
                    viewModel = viewModel,
                    orders = orders,
                    customers = customers,
                    vouchers = vouchers
                )
                Screen.DELIVERIES -> DeliveriesScreen(
                    viewModel = viewModel,
                    orders = orders,
                    onSelectInvoice = { viewModel.selectInvoiceForReceipt(it) }
                )
                Screen.SETTINGS -> ShopSettingsScreen(
                    viewModel = viewModel
                )
            }

            // Receipt Dialog Overlay
            selectedInvoice?.let { details ->
                InvoiceReceiptDialog(
                    details = details,
                    shopSettings = shopSettings,
                    onDismiss = { viewModel.clearSelectedInvoice() },
                    onStatusChange = { newStatus ->
                        viewModel.updateOrderStatus(details.order.id, newStatus)
                    }
                )
            }
        }
    }
}

