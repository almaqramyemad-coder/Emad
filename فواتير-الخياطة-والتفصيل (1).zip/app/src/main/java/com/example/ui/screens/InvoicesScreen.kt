package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.viewmodel.TailorViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoicesScreen(
    viewModel: TailorViewModel,
    orders: List<Order>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onNavigateToCreateInvoice: () -> Unit,
    onSelectInvoice: (Long) -> Unit
) {
    var selectedStatusFilter by remember { mutableStateOf<OrderStatus?>(null) }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

    val filteredList = orders.filter { order ->
        val matchesStatus = selectedStatusFilter == null || order.status == selectedStatusFilter
        matchesStatus
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToCreateInvoice,
                icon = { Icon(imageVector = Icons.Default.Add, contentDescription = null) },
                text = { Text("فاتورة جديدة") },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = Color.White,
                modifier = Modifier.testTag("invoices_fab_create")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("بحث برقم الفاتورة، اسم العميل، أو الجوال...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "بحث") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("invoices_search_input"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Status Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedStatusFilter == null,
                        onClick = { selectedStatusFilter = null },
                        label = { Text("الكل (${orders.size})") },
                        modifier = Modifier.testTag("filter_chip_all")
                    )
                }
                items(OrderStatus.entries.toTypedArray()) { status ->
                    val count = orders.count { it.status == status }
                    FilterChip(
                        selected = selectedStatusFilter == status,
                        onClick = { selectedStatusFilter = status },
                        label = { Text("${status.titleAr} ($count)") },
                        modifier = Modifier.testTag("filter_chip_${status.name}")
                    )
                }
            }

            Text(
                text = "الفواتير المسجلة (${filteredList.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "لا توجد فواتير مطابقة للبحث", color = Color.Gray)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredList, key = { it.id }) { order ->
                        InvoiceCardItem(
                            order = order,
                            dateFormat = dateFormat,
                            onClick = { onSelectInvoice(order.id) }
                        )
                    }
                }
            }
        }
    }
}
