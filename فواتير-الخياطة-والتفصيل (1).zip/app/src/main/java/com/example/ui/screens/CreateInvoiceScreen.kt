package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.viewmodel.OrderItemDraft
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.components.MeasurementInputField
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateInvoiceScreen(
    viewModel: TailorViewModel,
    customers: List<Customer>,
    onInvoiceSaved: (Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val formState by viewModel.newInvoiceState.collectAsState()
    val shopSettings by viewModel.shopSettings.collectAsState()

    var showCustomerPickerDropdown by remember { mutableStateOf(false) }

    // Calculated amounts
    val subtotal = formState.items.sumOf { it.unitPrice * it.quantity }
    val netBeforeTax = (subtotal - formState.discount).coerceAtLeast(0.0)
    val vatAmount = netBeforeTax * (shopSettings.vatRatePercent / 100.0)
    val totalAmount = netBeforeTax + vatAmount
    val remainingAmount = (totalAmount - formState.paidAmount).coerceAtLeast(0.0)

    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }
    val calculatedDeliveryDate = Date(System.currentTimeMillis() + (formState.deliveryDaysOffset * 86400000L))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "رجوع", tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "إنشاء فاتورة خياطة جديدة",
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Form Body Scroll
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SECTION 1: Customer Selection or Add New
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "1. بيانات العميل", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }

                        // Select existing customer button
                        Box {
                            OutlinedButton(
                                onClick = { showCustomerPickerDropdown = true },
                                modifier = Modifier.testTag("select_existing_customer_btn")
                            ) {
                                Text(if (formState.selectedCustomerId != null) "عميل مسجل" else "اختيار عميل سابق")
                                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(
                                expanded = showCustomerPickerDropdown,
                                onDismissRequest = { showCustomerPickerDropdown = false }
                            ) {
                                customers.forEach { customer ->
                                    DropdownMenuItem(
                                        text = { Text("${customer.name} - ${customer.phone}") },
                                        onClick = {
                                            viewModel.updateFormCustomer(customer.id, customer.name, customer.phone, customer.city)
                                            showCustomerPickerDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = formState.customerName,
                        onValueChange = { viewModel.updateFormCustomer(formState.selectedCustomerId, it, formState.customerPhone, formState.customerCity) },
                        label = { Text("اسم العميل كامل *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customer_name_input"),
                        singleLine = true
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formState.customerPhone,
                            onValueChange = { viewModel.updateFormCustomer(formState.selectedCustomerId, formState.customerName, it, formState.customerCity) },
                            label = { Text("رقم الجوال") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("customer_phone_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = formState.customerCity,
                            onValueChange = { viewModel.updateFormCustomer(formState.selectedCustomerId, formState.customerName, formState.customerPhone, it) },
                            label = { Text("المدينة") },
                            modifier = Modifier.weight(0.8f),
                            singleLine = true
                        )
                    }
                }
            }

            // SECTION 2: Tailoring Measurements
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Straighten, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "2. مقاسات التفصيل (بالسم CM)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الطول", value = formState.length.toString(), onValueChange = { viewModel.updateFormMeasurements(it.toDoubleOrNull() ?: 0.0, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الكتف", value = formState.shoulder.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, it.toDoubleOrNull() ?: 0.0, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الكم (اليد)", value = formState.sleeve.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, it.toDoubleOrNull() ?: 0.0, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الرقبة", value = formState.neck.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, it.toDoubleOrNull() ?: 0.0, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الصدر", value = formState.chest.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, it.toDoubleOrNull() ?: 0.0, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الخصر", value = formState.waist.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, it.toDoubleOrNull() ?: 0.0, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الوسع السفلي", value = formState.bottomWidth.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, it.toDoubleOrNull() ?: 0.0, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الكبك", value = formState.cuff.toString(), onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, it.toDoubleOrNull() ?: 0.0, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) }, modifier = Modifier.weight(1f))
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "تفضيلات ومواصفات التفصيل الخاصة:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                    // Preferred Fit
                    Text(text = "نوع القَصّة (Fit):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("عادي / Regular", "ضيق / Slim Fit", "وسيع / Loose Fit", "رسمي / Classic").forEach { fit ->
                            FilterChip(
                                selected = formState.fitPreference == fit,
                                onClick = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, fit, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                                label = { Text(fit, fontSize = 11.sp) }
                            )
                        }
                    }

                    // Sleeve Adjustment
                    Text(text = "تعديلات الكم (Sleeve Adjustments):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("بدون تعديل (قياسي)", "تطويل 1 سم (+1cm)", "تقصير 1 سم (-1cm)", "توسيع الإبط 1 سم").forEach { adj ->
                            FilterChip(
                                selected = formState.sleeveAdjustment == adj,
                                onClick = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, adj, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                                label = { Text(adj, fontSize = 11.sp) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formState.collarStyleDetail,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, it, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نمط وتصلّب القلاب") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = formState.shoulderType,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, it, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نوع الكتف") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formState.collarType,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, it, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نوع القلاب (اليقة)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = formState.buttonStyle,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, it, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نمط الأزرار") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formState.pocketType,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, it, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نوع الجيب") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = formState.fabricType,
                            onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, it, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, formState.customPreferences, formState.measurementNotes) },
                            label = { Text("نوع القماش المفضّل") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = formState.customPreferences,
                        onValueChange = { viewModel.updateFormMeasurements(formState.length, formState.shoulder, formState.sleeve, formState.neck, formState.chest, formState.waist, formState.bottomWidth, formState.cuff, formState.collarType, formState.pocketType, formState.fabricType, formState.fitPreference, formState.sleeveAdjustment, formState.collarStyleDetail, formState.shoulderType, formState.buttonStyle, it, formState.measurementNotes) },
                        label = { Text("تفضيلات وتوصيات تفصيل خاصة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // SECTION 3: Order Items & Pricing
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Checkroom, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "3. قطع التفصيل والأسعار", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                viewModel.addFormItem(OrderItemDraft(itemType = "ثوب كويتي فاخر", quantity = 1, unitPrice = 250.0))
                            },
                            modifier = Modifier.testTag("add_item_row_btn")
                        ) {
                            Icon(imageVector = Icons.Default.AddCircle, contentDescription = "إضافة قطعة", tint = MaterialTheme.colorScheme.secondary)
                        }
                    }

                    formState.items.forEachIndexed { index, item ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF8FAFC))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "القطعة #${index + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                if (formState.items.size > 1) {
                                    IconButton(
                                        onClick = { viewModel.removeFormItem(index) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = item.itemType,
                                onValueChange = { newType ->
                                    val list = formState.items.toMutableList()
                                    list[index] = item.copy(itemType = newType)
                                    viewModel.updateFormFinancials(formState.discount, formState.paidAmount, formState.paymentMethod, formState.deliveryDaysOffset, formState.notes)
                                },
                                label = { Text("نوع الصنف (ثوب سعودي، كويتي، فستان، إلخ)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = item.quantity.toString(),
                                    onValueChange = { qStr ->
                                        val list = formState.items.toMutableList()
                                        list[index] = item.copy(quantity = qStr.toIntOrNull() ?: 1)
                                        viewModel.updateFormFinancials(formState.discount, formState.paidAmount, formState.paymentMethod, formState.deliveryDaysOffset, formState.notes)
                                    },
                                    label = { Text("الكمية") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(0.8f),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = item.unitPrice.toString(),
                                    onValueChange = { pStr ->
                                        val list = formState.items.toMutableList()
                                        list[index] = item.copy(unitPrice = pStr.toDoubleOrNull() ?: 0.0)
                                        viewModel.updateFormFinancials(formState.discount, formState.paidAmount, formState.paymentMethod, formState.deliveryDaysOffset, formState.notes)
                                    },
                                    label = { Text("سعر القطعة (ر.س)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true
                                )
                            }
                        }
                    }
                }
            }

            // SECTION 4: Delivery Date & Financial Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "4. الحسابات والعربون وتاريخ التسليم", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    // Delivery Days Picker
                    Text(text = "تاريخ التسليم المتوقع:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            1 to "غداً (مستعجل)",
                            3 to "بعد 3 أيام",
                            5 to "بعد 5 أيام",
                            7 to "بعد أسبوع"
                        ).forEach { (days, label) ->
                            FilterChip(
                                selected = formState.deliveryDaysOffset == days,
                                onClick = {
                                    viewModel.updateFormFinancials(formState.discount, formState.paidAmount, formState.paymentMethod, days, formState.notes)
                                },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Text(
                        text = "التاريخ المحدد: ${dateFormat.format(calculatedDeliveryDate)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )

                    HorizontalDivider()

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formState.discount.toString(),
                            onValueChange = {
                                viewModel.updateFormFinancials(it.toDoubleOrNull() ?: 0.0, formState.paidAmount, formState.paymentMethod, formState.deliveryDaysOffset, formState.notes)
                            },
                            label = { Text("الخصم (ر.س)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = formState.paidAmount.toString(),
                            onValueChange = {
                                viewModel.updateFormFinancials(formState.discount, it.toDoubleOrNull() ?: 0.0, formState.paymentMethod, formState.deliveryDaysOffset, formState.notes)
                            },
                            label = { Text("العربون / المدفوع (ر.س)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("paid_amount_input"),
                            singleLine = true
                        )
                    }

                    // Payment method selection
                    Text(text = "طريقة الدفع:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("كاش", "شبكة مدى", "تحويل بنكي").forEach { method ->
                            FilterChip(
                                selected = formState.paymentMethod == method,
                                onClick = {
                                    viewModel.updateFormFinancials(formState.discount, formState.paidAmount, method, formState.deliveryDaysOffset, formState.notes)
                                },
                                label = { Text(method) }
                            )
                        }
                    }

                    // Summary Calculations Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المجموع قبل الضريبة:", fontSize = 12.sp, color = Color.DarkGray)
                            Text("$subtotal ر.س", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ضريبة القيمة المضافة (15%):", fontSize = 12.sp, color = Color.DarkGray)
                            Text("${String.format(Locale.US, "%.2f", vatAmount)} ر.س", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الإجمالي النهائي شامل الضريبة:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                            Text("${String.format(Locale.US, "%.2f", totalAmount)} ر.س", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("العربون المدفوع:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                            Text("${formState.paidAmount} ر.س", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المتبقي عند الاستلام:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                            Text("${String.format(Locale.US, "%.2f", remainingAmount)} ر.س", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFDC2626))
                        }
                    }
                }
            }
        }

        // Bottom Save & Generate Button
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 8.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Button(
                    onClick = {
                        if (formState.customerName.isBlank()) {
                            Toast.makeText(context, "يرجى إدخال اسم العميل", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.saveInvoice { orderId ->
                            Toast.makeText(context, "تم حفظ الفاتورة بنجاح 🎉", Toast.LENGTH_SHORT).show()
                            onInvoiceSaved(orderId)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_save_invoice_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Receipt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ واصدار الفاتورة", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
