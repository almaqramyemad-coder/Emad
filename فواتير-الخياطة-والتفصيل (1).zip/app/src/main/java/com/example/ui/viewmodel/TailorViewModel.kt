package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.TailorRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class NewInvoiceFormState(
    val selectedCustomerId: Long? = null,
    val customerName: String = "",
    val customerPhone: String = "",
    val customerCity: String = "الرياض",
    val deliveryDaysOffset: Int = 3,
    val items: List<OrderItemDraft> = listOf(OrderItemDraft(itemType = "ثوب كويتي فاخر", quantity = 1, unitPrice = 250.0)),
    val discount: Double = 0.0,
    val paidAmount: Double = 100.0,
    val paymentMethod: String = "كاش",
    val notes: String = "",

    // Measurement associated with this customer
    val length: Double = 145.0,
    val shoulder: Double = 46.0,
    val sleeve: Double = 61.0,
    val neck: Double = 42.0,
    val chest: Double = 58.0,
    val waist: Double = 56.0,
    val bottomWidth: Double = 82.0,
    val cuff: Double = 14.5,
    val collarType: String = "قلاب مربع",
    val pocketType: String = "جيب مخفي",
    val fabricType: String = "سلك ياباني فاخر",
    val fitPreference: String = "عادي / Regular",
    val sleeveAdjustment: String = "بدون تعديل (قياسي)",
    val collarStyleDetail: String = "قلاب كويتي مقوى",
    val shoulderType: String = "طبيعي / Natural",
    val buttonStyle: String = "أزرار مخفية",
    val customPreferences: String = "",
    val measurementNotes: String = ""
)

data class OrderItemDraft(
    val itemType: String = "ثوب كويتي فاخر",
    val quantity: Int = 1,
    val unitPrice: Double = 250.0,
    val fabricDetails: String = "سلك ياباني ممتاز"
)

data class SelectedInvoiceDetails(
    val order: Order,
    val items: List<OrderItem>,
    val customer: Customer?,
    val measurement: Measurement?
)

class TailorViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: TailorRepository
    
    init {
        val database = AppDatabase.getDatabase(application)
        repository = TailorRepository(
            database.customerDao(),
            database.measurementDao(),
            database.orderDao(),
            database.voucherDao()
        )
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vouchers: StateFlow<List<Voucher>> = repository.allVouchers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val filteredOrders: StateFlow<List<Order>> = combine(orders, searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter {
            it.customerName.contains(query, ignoreCase = true) ||
            it.orderNumber.contains(query, ignoreCase = true) ||
            it.customerPhone.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredCustomers: StateFlow<List<Customer>> = combine(customers, searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.phone.contains(query, ignoreCase = true) ||
            it.city.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Shop Settings
    private val _shopSettings = MutableStateFlow(ShopSettings())
    val shopSettings = _shopSettings.asStateFlow()

    // Invoice Form State
    private val _newInvoiceState = MutableStateFlow(NewInvoiceFormState())
    val newInvoiceState = _newInvoiceState.asStateFlow()

    // Selected Invoice Details for Receipt Modal
    private val _selectedInvoice = MutableStateFlow<SelectedInvoiceDetails?>(null)
    val selectedInvoice = _selectedInvoice.asStateFlow()

    // Selected Customer Details for Customer Profile Modal / View
    private val _selectedCustomer = MutableStateFlow<Customer?>(null)
    val selectedCustomer = _selectedCustomer.asStateFlow()

    private val _selectedCustomerMeasurement = MutableStateFlow<Measurement?>(null)
    val selectedCustomerMeasurement = _selectedCustomerMeasurement.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateShopSettings(settings: ShopSettings) {
        _shopSettings.value = settings
    }

    fun selectInvoiceForReceipt(orderId: Long) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId) ?: return@launch
            val items = repository.getOrderItemsDirect(orderId)
            val customer = repository.getCustomerById(order.customerId)
            val measurement = customer?.let { repository.getLatestMeasurementDirect(it.id) }
            _selectedInvoice.value = SelectedInvoiceDetails(order, items, customer, measurement)
        }
    }

    fun clearSelectedInvoice() {
        _selectedInvoice.value = null
    }

    fun selectCustomer(customer: Customer) {
        _selectedCustomer.value = customer
        viewModelScope.launch {
            _selectedCustomerMeasurement.value = repository.getLatestMeasurementDirect(customer.id)
        }
    }

    fun clearSelectedCustomer() {
        _selectedCustomer.value = null
        _selectedCustomerMeasurement.value = null
    }

    fun updateOrderStatus(orderId: Long, newStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
            // Refresh modal if open
            if (_selectedInvoice.value?.order?.id == orderId) {
                selectInvoiceForReceipt(orderId)
            }
        }
    }

    // New Invoice Form Actions
    fun updateFormCustomer(customerId: Long?, name: String, phone: String, city: String) {
        _newInvoiceState.update { current ->
            current.copy(
                selectedCustomerId = customerId,
                customerName = name,
                customerPhone = phone,
                customerCity = city
            )
        }
        if (customerId != null) {
            viewModelScope.launch {
                val m = repository.getLatestMeasurementDirect(customerId)
                if (m != null) {
                    _newInvoiceState.update { current ->
                        current.copy(
                            length = m.length,
                            shoulder = m.shoulder,
                            sleeve = m.sleeve,
                            neck = m.neck,
                            chest = m.chest,
                            waist = m.waist,
                            bottomWidth = m.bottomWidth,
                            cuff = m.cuff,
                            collarType = m.collarType,
                            pocketType = m.pocketType,
                            fabricType = m.fabricType,
                            fitPreference = m.fitPreference,
                            sleeveAdjustment = m.sleeveAdjustment,
                            collarStyleDetail = m.collarStyleDetail,
                            shoulderType = m.shoulderType,
                            buttonStyle = m.buttonStyle,
                            customPreferences = m.customPreferences,
                            measurementNotes = m.notes
                        )
                    }
                }
            }
        }
    }

    fun updateFormMeasurements(
        length: Double, shoulder: Double, sleeve: Double, neck: Double,
        chest: Double, waist: Double, bottomWidth: Double, cuff: Double,
        collarType: String, pocketType: String, fabricType: String,
        fitPreference: String = "عادي / Regular", sleeveAdjustment: String = "بدون تعديل (قياسي)",
        collarStyleDetail: String = "قلاب كويتي مقوى", shoulderType: String = "طبيعي / Natural",
        buttonStyle: String = "أزرار مخفية", customPreferences: String = "", notes: String = ""
    ) {
        _newInvoiceState.update {
            it.copy(
                length = length, shoulder = shoulder, sleeve = sleeve, neck = neck,
                chest = chest, waist = waist, bottomWidth = bottomWidth, cuff = cuff,
                collarType = collarType, pocketType = pocketType, fabricType = fabricType,
                fitPreference = fitPreference, sleeveAdjustment = sleeveAdjustment,
                collarStyleDetail = collarStyleDetail, shoulderType = shoulderType,
                buttonStyle = buttonStyle, customPreferences = customPreferences,
                measurementNotes = notes
            )
        }
    }

    fun addFormItem(item: OrderItemDraft) {
        _newInvoiceState.update {
            it.copy(items = it.items + item)
        }
    }

    fun removeFormItem(index: Int) {
        _newInvoiceState.update {
            if (it.items.size > 1) {
                val list = it.items.toMutableList()
                list.removeAt(index)
                it.copy(items = list)
            } else it
        }
    }

    fun updateFormFinancials(discount: Double, paidAmount: Double, paymentMethod: String, deliveryDays: Int, notes: String) {
        _newInvoiceState.update {
            it.copy(
                discount = discount,
                paidAmount = paidAmount,
                paymentMethod = paymentMethod,
                deliveryDaysOffset = deliveryDays,
                notes = notes
            )
        }
    }

    fun resetInvoiceForm() {
        _newInvoiceState.value = NewInvoiceFormState()
    }

    fun saveInvoice(onSuccess: (Long) -> Unit) {
        viewModelScope.launch {
            val form = _newInvoiceState.value
            if (form.customerName.isBlank()) return@launch

            // 1. Save or get customer
            val customerId = form.selectedCustomerId ?: repository.saveCustomer(
                Customer(
                    name = form.customerName,
                    phone = form.customerPhone.ifBlank { "0500000000" },
                    city = form.customerCity.ifBlank { "الرياض" }
                )
            )

            // 2. Save measurement
            repository.saveMeasurement(
                Measurement(
                    customerId = customerId,
                    length = form.length,
                    shoulder = form.shoulder,
                    sleeve = form.sleeve,
                    neck = form.neck,
                    chest = form.chest,
                    waist = form.waist,
                    bottomWidth = form.bottomWidth,
                    cuff = form.cuff,
                    collarType = form.collarType,
                    pocketType = form.pocketType,
                    fabricType = form.fabricType,
                    fitPreference = form.fitPreference,
                    sleeveAdjustment = form.sleeveAdjustment,
                    collarStyleDetail = form.collarStyleDetail,
                    shoulderType = form.shoulderType,
                    buttonStyle = form.buttonStyle,
                    customPreferences = form.customPreferences,
                    notes = form.measurementNotes
                )
            )

            // 3. Calculate Financials
            val subtotal = form.items.sumOf { it.unitPrice * it.quantity }
            val netBeforeTax = (subtotal - form.discount).coerceAtLeast(0.0)
            val taxAmount = netBeforeTax * (shopSettings.value.vatRatePercent / 100.0)
            val totalAmount = netBeforeTax + taxAmount
            val remainingAmount = (totalAmount - form.paidAmount).coerceAtLeast(0.0)

            val now = System.currentTimeMillis()
            val deliveryDate = now + (form.deliveryDaysOffset * 86400000L)
            val count = repository.allOrders.first().size + 1001
            val orderNum = "INV-2026-$count"

            val order = Order(
                orderNumber = orderNum,
                customerId = customerId,
                customerName = form.customerName,
                customerPhone = form.customerPhone.ifBlank { "0500000000" },
                orderDate = now,
                deliveryDate = deliveryDate,
                status = OrderStatus.NEW,
                subtotal = subtotal,
                discount = form.discount,
                taxAmount = taxAmount,
                totalAmount = totalAmount,
                paidAmount = form.paidAmount,
                remainingAmount = remainingAmount,
                paymentMethod = form.paymentMethod,
                notes = form.notes
            )

            val orderItems = form.items.map {
                OrderItem(
                    orderId = 0,
                    itemType = it.itemType,
                    quantity = it.quantity,
                    unitPrice = it.unitPrice,
                    fabricDetails = it.fabricDetails
                )
            }

            val newOrderId = repository.createInvoice(order, orderItems)
            resetInvoiceForm()
            selectInvoiceForReceipt(newOrderId)
            onSuccess(newOrderId)
        }
    }

    fun saveCustomerMeasurement(customerId: Long, m: Measurement, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.saveMeasurement(m.copy(customerId = customerId))
            _selectedCustomerMeasurement.value = m
            onComplete()
        }
    }

    fun createVoucher(
        voucherType: VoucherType,
        customerName: String,
        amount: Double,
        paymentMethod: String,
        description: String,
        customerId: Long? = null,
        orderId: Long? = null,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            val count = vouchers.value.size + 101
            val numPrefix = if (voucherType == VoucherType.RECEIPT) "REC" else "PAY"
            val voucherNumber = "VOU-$numPrefix-$count"
            val voucher = Voucher(
                voucherNumber = voucherNumber,
                voucherType = voucherType,
                customerId = customerId,
                customerName = customerName.ifBlank { "عميل عام" },
                orderId = orderId,
                amount = amount,
                paymentMethod = paymentMethod,
                description = description
            )
            repository.saveVoucher(voucher)
            onComplete()
        }
    }

    fun deleteVoucher(voucher: Voucher) {
        viewModelScope.launch {
            repository.deleteVoucher(voucher)
        }
    }
}

