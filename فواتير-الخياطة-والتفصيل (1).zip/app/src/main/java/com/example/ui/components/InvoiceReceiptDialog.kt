package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.OrderStatus
import com.example.data.model.ShopSettings
import com.example.data.viewmodel.SelectedInvoiceDetails
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceReceiptDialog(
    details: SelectedInvoiceDetails,
    shopSettings: ShopSettings,
    onDismiss: () -> Unit,
    onStatusChange: (OrderStatus) -> Unit
) {
    val context = LocalContext.current
    val order = details.order
    val items = details.items
    val measurement = details.measurement
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

    var showStatusDropdown by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "فاتورة خياطة ${order.orderNumber}",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row {
                        IconButton(
                            onClick = {
                                Toast.makeText(context, "جاري إرسال الفاتورة عبر واتساب...", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("share_whatsapp_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "مشاركة الفاتورة",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        IconButton(
                            onClick = {
                                Toast.makeText(context, "تمت طباعة الفاتورة بنجاح 🖨️", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("print_receipt_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = "طباعة الفاتورة",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_receipt_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }

                // Scrollable Thermal Invoice Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Invoice Card Canvas
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Header Logo & Shop Info
                            Icon(
                                imageVector = Icons.Default.ContentCut,
                                contentDescription = "Tailor Logo",
                                modifier = Modifier.size(36.dp),
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = shopSettings.shopName,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = shopSettings.address,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Text(
                                text = "هاتف: ${shopSettings.phone}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Row(
                                modifier = Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "س.ت: ${shopSettings.crNumber}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                                Text(
                                    text = "الرقم الضريبي: ${shopSettings.taxNumber}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Invoice Metadata Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "رقم الفاتورة", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = order.orderNumber,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "تاريخ الطلب", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = dateFormat.format(Date(order.orderDate)),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "تاريخ التسليم المحدد", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        text = dateFormat.format(Date(order.deliveryDate)),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                // Status Dropdown Selector
                                Box {
                                    OutlinedButton(
                                        onClick = { showStatusDropdown = true },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.testTag("change_status_btn")
                                    ) {
                                        OrderStatusChip(status = order.status)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = "تغيير الحالة",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showStatusDropdown,
                                        onDismissRequest = { showStatusDropdown = false }
                                    ) {
                                        OrderStatus.entries.forEach { st ->
                                            DropdownMenuItem(
                                                text = { Text(st.titleAr) },
                                                onClick = {
                                                    onStatusChange(st)
                                                    showStatusDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Customer Info
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFF8FAFC))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "بيانات العميل:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                                Text(
                                    text = order.customerName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "رقم الجوال: ${order.customerPhone}",
                                    fontSize = 13.sp,
                                    color = Color.DarkGray
                                )
                            }

                            // Optional Measurement Summary
                            if (measurement != null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFFFFBEB))
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "مقاسات التفصيل المسجلة:",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                        Text(
                                            text = "${measurement.fabricType}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "الطول: ${measurement.length}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الكتف: ${measurement.shoulder}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الكم: ${measurement.sleeve}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الرقبة: ${measurement.neck}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "الصدر: ${measurement.chest}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الخصر: ${measurement.waist}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الأسفل: ${measurement.bottomWidth}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "الكبك: ${measurement.cuff}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "النمط والقَصّة: ${measurement.fitPreference} | كم: ${measurement.sleeveAdjustment}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB45309)
                                    )
                                    Text(
                                        text = "القلاب: ${measurement.collarType} (${measurement.collarStyleDetail}) | الكتف: ${measurement.shoulderType}",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                    Text(
                                        text = "الأزرار: ${measurement.buttonStyle} | الجيب: ${measurement.pocketType}",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                    if (measurement.customPreferences.isNotBlank()) {
                                        Text(
                                            text = "التفضيلات الخاصة: ${measurement.customPreferences}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Items Table
                            Text(
                                text = "تفاصيل القطع والمواصفات",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                textAlign = TextAlign.Start
                            )

                            // Table Header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFE2E8F0))
                                    .padding(vertical = 6.dp, horizontal = 8.dp)
                            ) {
                                Text(text = "الصنف والنوع", modifier = Modifier.weight(2f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "العدد", modifier = Modifier.weight(0.8f), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text(text = "السعر", modifier = Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                                Text(text = "الإجمالي", modifier = Modifier.weight(1.2f), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                            }

                            items.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(2f)) {
                                        Text(text = item.itemType, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        if (item.fabricDetails.isNotBlank()) {
                                            Text(text = item.fabricDetails, fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }
                                    Text(text = "${item.quantity}", modifier = Modifier.weight(0.8f), fontSize = 13.sp, textAlign = TextAlign.Center)
                                    Text(text = "${item.unitPrice} ر.س", modifier = Modifier.weight(1f), fontSize = 13.sp, textAlign = TextAlign.End)
                                    Text(text = "${item.quantity * item.unitPrice} ر.س", modifier = Modifier.weight(1.2f), fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                                }
                                HorizontalDivider(color = Color(0xFFF1F5F9))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Financial Summary Box
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                FinancialRow("المجموع الفرعي:", "${order.subtotal} ر.س")
                                if (order.discount > 0) {
                                    FinancialRow("الخصم:", "- ${order.discount} ر.س", color = Color(0xFFDC2626))
                                }
                                FinancialRow("ضريبة القيمة المضافة (15%):", "${String.format(Locale.US, "%.2f", order.taxAmount)} ر.س")
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                                FinancialRow("الإجمالي النهائي شامل الضريبة:", "${String.format(Locale.US, "%.2f", order.totalAmount)} ر.س", isBold = true, fontSize = 15)
                                FinancialRow("العربون / المدفوع (${order.paymentMethod}):", "${order.paidAmount} ر.س", color = Color(0xFF16A34A), isBold = true)
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                                FinancialRow(
                                    label = "المتبقي عند الاستلام:",
                                    value = "${String.format(Locale.US, "%.2f", order.remainingAmount)} ر.س",
                                    color = if (order.remainingAmount > 0) Color(0xFFDC2626) else Color(0xFF16A34A),
                                    isBold = true,
                                    fontSize = 16
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // QR / Barcode Visual Simulation
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "||||| |||||||||| ||||||||||| |||||",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 24.sp,
                                    letterSpacing = 2.sp,
                                    color = Color.Black
                                )
                                Text(text = order.orderNumber, fontSize = 10.sp, color = Color.Gray)
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = shopSettings.invoiceTerms,
                                fontSize = 10.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Bottom Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            Toast.makeText(context, "تم إرسال الفاتورة عبر واتساب إلى ${order.customerPhone}", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("send_whatsapp_bottom_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إرسال واتساب")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dismiss_receipt_btn")
                    ) {
                        Text("إغلاق")
                    }
                }
            }
        }
    }
}

@Composable
fun FinancialRow(
    label: String,
    value: String,
    color: Color = Color.Unspecified,
    isBold: Boolean = false,
    fontSize: Int = 13
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = fontSize.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (color != Color.Unspecified) color else Color.DarkGray
        )
        Text(
            text = value,
            fontSize = fontSize.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (color != Color.Unspecified) color else Color(0xFF0F172A)
        )
    }
}
