package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Measurement

@Composable
fun MeasurementFormDialog(
    initialMeasurement: Measurement?,
    customerName: String,
    onDismiss: () -> Unit,
    onSave: (Measurement) -> Unit
) {
    var length by remember { mutableStateOf(initialMeasurement?.length?.toString() ?: "145.0") }
    var shoulder by remember { mutableStateOf(initialMeasurement?.shoulder?.toString() ?: "46.0") }
    var sleeve by remember { mutableStateOf(initialMeasurement?.sleeve?.toString() ?: "61.0") }
    var neck by remember { mutableStateOf(initialMeasurement?.neck?.toString() ?: "42.0") }
    var chest by remember { mutableStateOf(initialMeasurement?.chest?.toString() ?: "58.0") }
    var waist by remember { mutableStateOf(initialMeasurement?.waist?.toString() ?: "56.0") }
    var bottomWidth by remember { mutableStateOf(initialMeasurement?.bottomWidth?.toString() ?: "82.0") }
    var cuff by remember { mutableStateOf(initialMeasurement?.cuff?.toString() ?: "14.5") }
    var collarType by remember { mutableStateOf(initialMeasurement?.collarType ?: "قلاب مربع") }
    var pocketType by remember { mutableStateOf(initialMeasurement?.pocketType ?: "جيب مخفي") }
    var fabricType by remember { mutableStateOf(initialMeasurement?.fabricType ?: "سلك ياباني فاخر") }
    var fitPreference by remember { mutableStateOf(initialMeasurement?.fitPreference ?: "عادي / Regular") }
    var sleeveAdjustment by remember { mutableStateOf(initialMeasurement?.sleeveAdjustment ?: "بدون تعديل (قياسي)") }
    var collarStyleDetail by remember { mutableStateOf(initialMeasurement?.collarStyleDetail ?: "قلاب كويتي مقوى") }
    var shoulderType by remember { mutableStateOf(initialMeasurement?.shoulderType ?: "طبيعي / Natural") }
    var buttonStyle by remember { mutableStateOf(initialMeasurement?.buttonStyle ?: "أزرار مخفية") }
    var customPreferences by remember { mutableStateOf(initialMeasurement?.customPreferences ?: "") }
    var notes by remember { mutableStateOf(initialMeasurement?.notes ?: "") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.SquareFoot, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تعديل مقاسات: $customerName",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "المقاسات الأساسية بالسم (CM)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // 2x2 Grid of measurement inputs
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الطول الكلي", value = length, onValueChange = { length = it }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الكتف", value = shoulder, onValueChange = { shoulder = it }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "طول الكم (اليد)", value = sleeve, onValueChange = { sleeve = it }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "دوران الرقبة", value = neck, onValueChange = { neck = it }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الصدر", value = chest, onValueChange = { chest = it }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الخصر / الوسط", value = waist, onValueChange = { waist = it }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MeasurementInputField(label = "الوسع السفلي", value = bottomWidth, onValueChange = { bottomWidth = it }, modifier = Modifier.weight(1f))
                        MeasurementInputField(label = "الكبك / الأسورة", value = cuff, onValueChange = { cuff = it }, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "مواصفات وتفضيلات الخياطة المخصصة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Fit Preference selector
                    Text(text = "تفصيل القَصّة (Preferred Fit):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("عادي / Regular", "ضيق / Slim Fit", "وسيع / Loose Fit", "رسمي / Classic").forEach { fit ->
                            FilterChip(
                                selected = fitPreference == fit,
                                onClick = { fitPreference = fit },
                                label = { Text(fit, fontSize = 11.sp) }
                            )
                        }
                    }

                    // Sleeve Adjustment selector
                    Text(text = "تعديلات الأكمام واليدين (Sleeve Adjustments):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("بدون تعديل (قياسي)", "تطويل 1 سم (+1cm)", "تطويل 2 سم (+2cm)", "تقصير 1 سم (-1cm)", "توسيع الإبط 1 سم").forEach { adj ->
                            FilterChip(
                                selected = sleeveAdjustment == adj,
                                onClick = { sleeveAdjustment = adj },
                                label = { Text(adj, fontSize = 11.sp) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = collarStyleDetail,
                            onValueChange = { collarStyleDetail = it },
                            label = { Text("تفاصيل وتصلّب القلاب") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = shoulderType,
                            onValueChange = { shoulderType = it },
                            label = { Text("نوع وتصميم الكتف") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = collarType,
                            onValueChange = { collarType = it },
                            label = { Text("نوع القلاب (اليقة)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = buttonStyle,
                            onValueChange = { buttonStyle = it },
                            label = { Text("نوع ونمط الأزرار") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pocketType,
                            onValueChange = { pocketType = it },
                            label = { Text("نوع الجيب والتصميم") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = fabricType,
                            onValueChange = { fabricType = it },
                            label = { Text("نوع القماش المفضّل") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = customPreferences,
                        onValueChange = { customPreferences = it },
                        label = { Text("تفضيلات الخياطة الخاصة (تكسير جوانب، خياطة مضاعفة...)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات قياسية إضافية") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                // Action buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            val updated = Measurement(
                                id = initialMeasurement?.id ?: 0,
                                customerId = initialMeasurement?.customerId ?: 0,
                                length = length.toDoubleOrNull() ?: 145.0,
                                shoulder = shoulder.toDoubleOrNull() ?: 46.0,
                                sleeve = sleeve.toDoubleOrNull() ?: 61.0,
                                neck = neck.toDoubleOrNull() ?: 42.0,
                                chest = chest.toDoubleOrNull() ?: 58.0,
                                waist = waist.toDoubleOrNull() ?: 56.0,
                                bottomWidth = bottomWidth.toDoubleOrNull() ?: 82.0,
                                cuff = cuff.toDoubleOrNull() ?: 14.5,
                                collarType = collarType,
                                pocketType = pocketType,
                                fabricType = fabricType,
                                fitPreference = fitPreference,
                                sleeveAdjustment = sleeveAdjustment,
                                collarStyleDetail = collarStyleDetail,
                                shoulderType = shoulderType,
                                buttonStyle = buttonStyle,
                                customPreferences = customPreferences,
                                notes = notes,
                                updatedAt = System.currentTimeMillis()
                            )
                            onSave(updated)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_measurement_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("حفظ المقاسات")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

@Composable
fun MeasurementInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
        singleLine = true
    )
}
