package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Customer
import com.example.data.model.Voucher
import com.example.data.model.VoucherType
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.theme.GoldAccent
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VouchersScreen(
    viewModel: TailorViewModel,
    vouchers: List<Voucher>,
    customers: List<Customer>
) {
    var selectedFilter by remember { mutableStateOf<VoucherType?>(null) } // null = All
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedVoucherForReceipt by remember { mutableStateOf<Voucher?>(null) }

    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }

    val filteredVouchers = vouchers.filter { voucher ->
        (selectedFilter == null || voucher.voucherType == selectedFilter) &&
        (searchQuery.isBlank() || voucher.customerName.contains(searchQuery, ignoreCase = true) || voucher.voucherNumber.contains(searchQuery, ignoreCase = true) || voucher.description.contains(searchQuery, ignoreCase = true))
    }

    val totalReceipts = vouchers.filter { it.voucherType == VoucherType.RECEIPT }.sumOf { it.amount }
    val totalPayments = vouchers.filter { it.voucherType == VoucherType.PAYMENT }.sumOf { it.amount }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_voucher_fab")
            ) {
                Icon(imageVector = Icons.Default.AddCard, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("سند جديد", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header Stats Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF86EFAC)))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إجمالي المقبوضات", fontSize = 11.sp, color = Color(0xFF15803D), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${String.format(Locale.US, "%.2f", totalReceipts)} ر.س",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF166534)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFCA5A5)))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إجمالي المصروفات", fontSize = 11.sp, color = Color(0xFF991B1B), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${String.format(Locale.US, "%.2f", totalPayments)} ر.س",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voucher_search_input"),
                placeholder = { Text("بحث باسم العميل أو رقم السند...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    label = { Text("جميع السندات (${vouchers.size})") }
                )
                FilterChip(
                    selected = selectedFilter == VoucherType.RECEIPT,
                    onClick = { selectedFilter = VoucherType.RECEIPT },
                    label = { Text("سندات قبض (${vouchers.count { it.voucherType == VoucherType.RECEIPT }})") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFDCFCE7))
                )
                FilterChip(
                    selected = selectedFilter == VoucherType.PAYMENT,
                    onClick = { selectedFilter = VoucherType.PAYMENT },
                    label = { Text("سندات صرف (${vouchers.count { it.voucherType == VoucherType.PAYMENT }})") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFEE2E2))
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Voucher List
            if (filteredVouchers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("لا توجد سندات مسجلة بهذه الفلترة", color = Color.Gray)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredVouchers, key = { it.id }) { voucher ->
                        VoucherCardItem(
                            voucher = voucher,
                            dateFormat = dateFormat,
                            onClick = { selectedVoucherForReceipt = voucher },
                            onDelete = { viewModel.deleteVoucher(voucher) }
                        )
                    }
                }
            }
        }
    }

    // Add Voucher Dialog
    if (showAddDialog) {
        AddVoucherDialog(
            customers = customers,
            onDismiss = { showAddDialog = false },
            onConfirm = { type, customerName, amount, payMethod, desc, customerId ->
                viewModel.createVoucher(
                    voucherType = type,
                    customerName = customerName,
                    amount = amount,
                    paymentMethod = payMethod,
                    description = desc,
                    customerId = customerId,
                    onComplete = { showAddDialog = false }
                )
            }
        )
    }

    // Voucher Receipt Preview Modal
    selectedVoucherForReceipt?.let { voucher ->
        VoucherReceiptPreviewModal(
            voucher = voucher,
            shopName = viewModel.shopSettings.collectAsState().value.shopName,
            dateFormat = dateFormat,
            onDismiss = { selectedVoucherForReceipt = null }
        )
    }
}

@Composable
fun VoucherCardItem(
    voucher: Voucher,
    dateFormat: SimpleDateFormat,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val isReceipt = voucher.voucherType == VoucherType.RECEIPT
    val badgeBg = if (isReceipt) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
    val badgeTextColor = if (isReceipt) Color(0xFF15803D) else Color(0xFFB91C1C)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("voucher_item_${voucher.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(badgeBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isReceipt) Icons.Default.CallReceived else Icons.Default.CallMade,
                    contentDescription = null,
                    tint = badgeTextColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = voucher.voucherNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.2f", voucher.amount)} ر.س",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = if (isReceipt) Color(0xFF166534) else Color(0xFF991B1B)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "العميل / البيان: ${voucher.customerName}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF0F172A)
                )

                if (voucher.description.isNotBlank()) {
                    Text(
                        text = voucher.description,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "طريقة الدفع: ${voucher.paymentMethod}", fontSize = 10.sp, color = Color.DarkGray)
                    Text(text = dateFormat.format(Date(voucher.date)), fontSize = 10.sp, color = Color.Gray)
                }
            }

            IconButton(onClick = onDelete) {
                Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "حذف", tint = Color.LightGray)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddVoucherDialog(
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onConfirm: (VoucherType, String, Double, String, String, Long?) -> Unit
) {
    var voucherType by remember { mutableStateOf(VoucherType.RECEIPT) }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var customName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("كاش / نقداً") }
    var description by remember { mutableStateOf("") }

    var isCustomerMenuExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (voucherType == VoucherType.RECEIPT) "إصدار سند قبض جديد" else "إصدار سند صرف جديد",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Type Toggle
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = voucherType == VoucherType.RECEIPT,
                        onClick = { voucherType = VoucherType.RECEIPT },
                        label = { Text("سند قبض (استلام مبلغ)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = voucherType == VoucherType.PAYMENT,
                        onClick = { voucherType = VoucherType.PAYMENT },
                        label = { Text("سند صرف (دفع/مصروفات)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Customer selection dropdown or manual name
                ExposedDropdownMenuBox(
                    expanded = isCustomerMenuExpanded,
                    onExpandedChange = { isCustomerMenuExpanded = !isCustomerMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCustomer?.name ?: customName,
                        onValueChange = {
                            customName = it
                            selectedCustomer = null
                        },
                        label = { Text("اسم العميل / المستفيد") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCustomerMenuExpanded) },
                        singleLine = true
                    )
                    ExposedDropdownMenu(
                        expanded = isCustomerMenuExpanded,
                        onDismissRequest = { isCustomerMenuExpanded = false }
                    ) {
                        customers.forEach { customer ->
                            DropdownMenuItem(
                                text = { Text("${customer.name} (${customer.phone})") },
                                onClick = {
                                    selectedCustomer = customer
                                    customName = customer.name
                                    isCustomerMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("المبلغ (ر.س)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("طريقة الدفع/التحصيل:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("كاش / نقداً", "شبكة مدى", "تحويل بنكي", "تحويل سريع").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("البيان / السبب (مثلاً: دفعة مقدمة خياطة ثوب)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull() ?: 0.0
                            val finalName = selectedCustomer?.name ?: customName
                            if (amount > 0 && finalName.isNotBlank()) {
                                onConfirm(voucherType, finalName, amount, paymentMethod, description, selectedCustomer?.id)
                            }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("حفظ السند")
                    }
                }
            }
        }
    }
}

@Composable
fun VoucherReceiptPreviewModal(
    voucher: Voucher,
    shopName: String,
    dateFormat: SimpleDateFormat,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Text(
                    text = shopName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (voucher.voucherType == VoucherType.RECEIPT) "سند قبض رسمي" else "سند صرف رسمي",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GoldAccent
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(12.dp))

                // Voucher details table layout
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), shape = RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("رقم السند:", fontSize = 12.sp, color = Color.Gray)
                        Text(voucher.voucherNumber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("التاريخ والوقت:", fontSize = 12.sp, color = Color.Gray)
                        Text(dateFormat.format(Date(voucher.date)), fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("استلمنا من السيد/المستفيد:", fontSize = 12.sp, color = Color.Gray)
                        Text(voucher.customerName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("طريقة الدفع:", fontSize = 12.sp, color = Color.Gray)
                        Text(voucher.paymentMethod, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    HorizontalDivider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("المبلغ الإجمالي:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${String.format(Locale.US, "%.2f", voucher.amount)} ر.س",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (voucher.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("وذلك مقابل (البيان):", fontSize = 12.sp, color = Color.Gray)
                        Text(voucher.description, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Mock Stamp & Signature Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ختم المحل الرسمي", fontSize = 11.sp, color = Color.Gray)
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEFF6FF))
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("توقيع المستلم / المحاسب", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("________", fontSize = 14.sp, color = Color.DarkGray)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إغلاق السند")
                }
            }
        }
    }
}
