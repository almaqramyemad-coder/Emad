package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Measurement
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.components.MeasurementFormDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    viewModel: TailorViewModel,
    customers: List<Customer>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onNavigateToCreateInvoice: () -> Unit
) {
    val context = LocalContext.current
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var customerToEditMeasurement by remember { mutableStateOf<Pair<Customer, Measurement?>?>(null) }

    val selectedCustomer by viewModel.selectedCustomer.collectAsState()
    val selectedMeasurement by viewModel.selectedCustomerMeasurement.collectAsState()

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddCustomerDialog = true },
                icon = { Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null) },
                text = { Text("عميل جديد") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_customer_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("بحث باسم العميل أو رقم الجوال...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "بحث") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customers_search_input"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            Text(
                text = "قاعدة بيانات العملاء (${customers.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            if (customers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "لا يوجد عملاء مسجلين", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(customers, key = { it.id }) { customer ->
                        CustomerCardItem(
                            customer = customer,
                            onClick = { viewModel.selectCustomer(customer) }
                        )
                    }
                }
            }
        }
    }

    // Edit Measurement Modal
    if (customerToEditMeasurement != null) {
        val (cust, meas) = customerToEditMeasurement!!
        MeasurementFormDialog(
            initialMeasurement = meas,
            customerName = cust.name,
            onDismiss = { customerToEditMeasurement = null },
            onSave = { updatedMeas ->
                viewModel.saveCustomerMeasurement(cust.id, updatedMeas) {
                    Toast.makeText(context, "تم حفظ مقاسات ${cust.name} بنجاح", Toast.LENGTH_SHORT).show()
                    customerToEditMeasurement = null
                }
            }
        )
    }

    // Customer Profile Detail Modal
    if (selectedCustomer != null) {
        val cust = selectedCustomer!!
        AlertDialog(
            onDismissRequest = { viewModel.clearSelectedCustomer() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(cust.name, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الجوال: ${cust.phone}", fontSize = 14.sp, color = Color.DarkGray)
                    Text("المدينة: ${cust.city}", fontSize = 14.sp, color = Color.DarkGray)
                    if (cust.notes.isNotBlank()) {
                        Text("ملاحظات: ${cust.notes}", fontSize = 13.sp, color = Color.Gray)
                    }

                    HorizontalDivider()

                    Text("مقاسات التفصيل المسجلة:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    if (selectedMeasurement == null) {
                        Text("لا توجد مقاسات مسجلة بعد لهذا العميل", fontSize = 12.sp, color = Color.Gray)
                    } else {
                        val m = selectedMeasurement!!
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFFFBEB))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("الطول: ${m.length} سم | الكتف: ${m.shoulder} سم", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("الكم: ${m.sleeve} سم | الرقبة: ${m.neck} سم", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("الصدر: ${m.chest} سم | الخصر: ${m.waist} سم", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("الكبك: ${m.cuff} سم | الوسع: ${m.bottomWidth} سم", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("القَصّة: ${m.fitPreference} | الكم: ${m.sleeveAdjustment}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text("التصميم: ${m.collarType} (${m.collarStyleDetail}) | الكتف: ${m.shoulderType}", fontSize = 11.sp, color = Color.DarkGray)
                            Text("الأزرار: ${m.buttonStyle} | الجيب: ${m.pocketType}", fontSize = 11.sp, color = Color.DarkGray)
                            if (m.fabricType.isNotBlank()) {
                                Text("القماش: ${m.fabricType}", fontSize = 11.sp, color = Color.DarkGray)
                            }
                            if (m.customPreferences.isNotBlank()) {
                                Text("التفضيلات الخاصة: ${m.customPreferences}", fontSize = 11.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        customerToEditMeasurement = cust to selectedMeasurement
                    },
                    modifier = Modifier.testTag("customer_edit_measurements_btn")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل المقاسات")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.clearSelectedCustomer() }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Add New Customer Modal
    if (showAddCustomerDialog) {
        var newName by remember { mutableStateOf("") }
        var newPhone by remember { mutableStateOf("") }
        var newCity by remember { mutableStateOf("الرياض") }
        var newNotes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddCustomerDialog = false },
            title = { Text("إضافة عميل جديد", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("اسم العميل *") },
                        singleLine = true,
                        modifier = Modifier.testTag("dialog_new_customer_name")
                    )
                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = { newPhone = it },
                        label = { Text("رقم الجوال") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = newCity,
                        onValueChange = { newCity = it },
                        label = { Text("المدينة") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newNotes,
                        onValueChange = { newNotes = it },
                        label = { Text("ملاحظات العميل") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) {
                            viewModel.updateFormCustomer(null, newName, newPhone, newCity)
                            showAddCustomerDialog = false
                            onNavigateToCreateInvoice()
                        }
                    },
                    modifier = Modifier.testTag("confirm_add_customer_btn")
                ) {
                    Text("حفظ وإنشاء فاتورة")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddCustomerDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun CustomerCardItem(
    customer: Customer,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("customer_card_${customer.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = customer.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Text(text = "جوال: ${customer.phone}", fontSize = 12.sp, color = Color.Gray)
                    if (customer.notes.isNotBlank()) {
                        Text(text = customer.notes, fontSize = 11.sp, color = Color(0xFFD97706))
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = "عرض الملف",
                tint = Color.Gray
            )
        }
    }
}
