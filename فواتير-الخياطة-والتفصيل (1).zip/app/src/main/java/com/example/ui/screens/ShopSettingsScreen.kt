package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShopSettings
import com.example.data.viewmodel.TailorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopSettingsScreen(
    viewModel: TailorViewModel
) {
    val context = LocalContext.current
    val currentSettings by viewModel.shopSettings.collectAsState()

    var shopName by remember(currentSettings) { mutableStateOf(currentSettings.shopName) }
    var phone by remember(currentSettings) { mutableStateOf(currentSettings.phone) }
    var crNumber by remember(currentSettings) { mutableStateOf(currentSettings.crNumber) }
    var taxNumber by remember(currentSettings) { mutableStateOf(currentSettings.taxNumber) }
    var address by remember(currentSettings) { mutableStateOf(currentSettings.address) }
    var invoiceTerms by remember(currentSettings) { mutableStateOf(currentSettings.invoiceTerms) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "بيانات وإعدادات محل الخياطة",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = shopName,
                onValueChange = { shopName = it },
                label = { Text("اسم المحل المعروض في الفواتير") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_shop_name_input"),
                singleLine = true
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("رقم جوال المحل للتواصل") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = crNumber,
                    onValueChange = { crNumber = it },
                    label = { Text("رقم السجل التجاري (CR)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                OutlinedTextField(
                    value = taxNumber,
                    onValueChange = { taxNumber = it },
                    label = { Text("الرقم الضريبي (VAT)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("عنوان المحل والمدينة") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = invoiceTerms,
                onValueChange = { invoiceTerms = it },
                label = { Text("شروط وملاحظات الفاتورة السفلى") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    val updated = ShopSettings(
                        shopName = shopName,
                        phone = phone,
                        crNumber = crNumber,
                        taxNumber = taxNumber,
                        address = address,
                        invoiceTerms = invoiceTerms
                    )
                    viewModel.updateShopSettings(updated)
                    Toast.makeText(context, "تم حفظ إعدادات المحل بنجاح 💾", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("settings_save_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ البيانات والتغييرات", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
