package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldLight,
    onPrimary = NavyPrimary,
    primaryContainer = NavySecondary,
    onPrimaryContainer = GoldLight,
    secondary = GoldAccent,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = WarmBackground,
    onSurface = WarmBackground
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = ForestGreenContainer,
    onPrimaryContainer = CharcoalText,
    secondary = SageAccent,
    onSecondary = Color.White,
    secondaryContainer = WarmGoldAccent.copy(alpha = 0.2f),
    onSecondaryContainer = CharcoalText,
    background = SandBackground,
    surface = SandSurface,
    surfaceVariant = SandSurfaceVariant,
    onBackground = CharcoalText,
    onSurface = CharcoalText,
    onSurfaceVariant = MutedText
)

@Composable
fun TailorInvoiceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

