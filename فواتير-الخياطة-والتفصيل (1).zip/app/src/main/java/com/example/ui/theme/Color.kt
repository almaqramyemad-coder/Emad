package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Natural Tones Palette
val SandBackground = Color(0xFFFCF9F1)
val SandSurface = Color(0xFFFFFFFF)
val SandSurfaceVariant = Color(0xFFF5F1E6)
val ForestGreenPrimary = Color(0xFF4B6149)
val ForestGreenContainer = Color(0xFFE8E3D4)
val SageAccent = Color(0xFF688266)
val WarmGoldAccent = Color(0xFFD4A373)
val CharcoalText = Color(0xFF1A1C19)
val MutedText = Color(0xFF79747E)

// Legacy aliases for backward compatibility
val NavyPrimary = ForestGreenPrimary
val NavySecondary = SageAccent
val GoldAccent = WarmGoldAccent
val GoldLight = Color(0xFFE8C598)
val WarmBackground = SandBackground
val CardSurface = SandSurface

// Natural Status Badge Colors
val StatusNew = Color(0xFF3A7580)        // Natural Slate Teal
val StatusCutting = Color(0xFF4B6149)    // Forest Green
val StatusSewing = Color(0xFFD4A373)     // Warm Amber/Bronze
val StatusReady = Color(0xFF2E7D32)      // Olive Green
val StatusDelivered = Color(0xFF79747E)  // Muted Natural Gray

val DarkBackground = Color(0xFF1C1E1B)
val DarkSurface = Color(0xFF272A26)


