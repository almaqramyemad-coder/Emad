package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.components.OrderStatusChip
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DeliveriesScreen(
    viewModel: TailorViewModel,
    orders: List<Order>,
    onSelectInvoice: (Long) -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }
    val now = System.currentTimeMillis()

    var activeTab by remember { mutableStateOf(0) } // 0: Today/Urgent, 1: Pending, 2: Ready, 3: Delivered

    val urgentOrders = orders.filter {
        it.status != OrderStatus.DELIVERED && (it.deliveryDate - now) <= 86400000L
    }.sortedBy { it.deliveryDate }

    val pendingOrders = orders.filter {
        it.status == OrderStatus.NEW || it.status == OrderStatus.CUTTING || it.status == OrderStatus.SEWING
    }.sortedBy { it.deliveryDate }

    val readyOrders = orders.filter {
        it.status == OrderStatus.READY
    }.sortedBy { it.deliveryDate }

    val deliveredOrders = orders.filter {
        it.status == OrderStatus.DELIVERED
    }.sortedByDescending { it.deliveryDate }

    val currentDisplayList = when (activeTab) {
        0 -> urgentOrders
        1 -> pendingOrders
        2 -> readyOrders
        else -> deliveredOrders
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "جدول ومتابعة تواريخ التسليم",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Filter Tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    label = { Text("تسليم اليوم (${urgentOrders.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFDC2626),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("tab_deliveries_urgent")
                )
            }
            item {
                FilterChip(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    label = { Text("قيد التفصيل (${pendingOrders.size})") },
                    modifier = Modifier.testTag("tab_deliveries_pending")
                )
            }
            item {
                FilterChip(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    label = { Text("جاهز للتسليم (${readyOrders.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF16A34A),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("tab_deliveries_ready")
                )
            }
            item {
                FilterChip(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    label = { Text("تم التسليم (${deliveredOrders.size})") },
                    modifier = Modifier.testTag("tab_deliveries_completed")
                )
            }
        }

        if (currentDisplayList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "لا توجد طلبات في هذا القسم حالياً", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(currentDisplayList, key = { it.id }) { order ->
                    DeliveryOrderCard(
                        order = order,
                        dateFormat = dateFormat,
                        onSelect = { onSelectInvoice(order.id) },
                        onNextStatus = { nextStatus ->
                            viewModel.updateOrderStatus(order.id, nextStatus)
                            if (nextStatus == OrderStatus.READY) {
                                Toast.makeText(context, "تم تغيير الحالة لـ (جاهز) وإرسال إشعار للعميل 📱", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "تم تحديث حالة الطلب إلى: ${nextStatus.titleAr}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DeliveryOrderCard(
    order: Order,
    dateFormat: SimpleDateFormat,
    onSelect: () -> Unit,
    onNextStatus: (OrderStatus) -> Unit
) {
    val diffDays = ((order.deliveryDate - System.currentTimeMillis()) / 86400000L).toInt()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("delivery_card_${order.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = order.orderNumber, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Spacer(modifier = Modifier.width(8.dp))
                    OrderStatusChip(status = order.status)
                }

                // Days left badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when {
                                order.status == OrderStatus.DELIVERED -> Color(0xFFF1F5F9)
                                diffDays <= 0 -> Color(0xFFFEF2F2)
                                diffDays <= 2 -> Color(0xFFFFFBEB)
                                else -> Color(0xFFF0FDF4)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when {
                            order.status == OrderStatus.DELIVERED -> "مكتمل"
                            diffDays < 0 -> "متأخر $abs(${diffDays}) يوم"
                            diffDays == 0 -> "تاريخ التسليم اليوم!"
                            else -> "باقي $diffDays أيام"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            order.status == OrderStatus.DELIVERED -> Color.Gray
                            diffDays <= 0 -> Color(0xFFDC2626)
                            diffDays <= 2 -> Color(0xFFD97706)
                            else -> Color(0xFF16A34A)
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = order.customerName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Text(text = "الجوال: ${order.customerPhone}", fontSize = 12.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "تاريخ التسليم:", fontSize = 10.sp, color = Color.Gray)
                    Text(text = dateFormat.format(Date(order.deliveryDate)), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }

            HorizontalDivider()

            // Financial & Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "الإجمالي: ${order.totalAmount} ر.س", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (order.remainingAmount > 0) {
                        Text(text = "المتبقي: ${order.remainingAmount} ر.س", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                    } else {
                        Text(text = "مدفوع بالكامل", fontSize = 11.sp, color = Color(0xFF16A34A))
                    }
                }

                // Workflow Action Button
                val nextStatus = when (order.status) {
                    OrderStatus.NEW -> OrderStatus.CUTTING
                    OrderStatus.CUTTING -> OrderStatus.SEWING
                    OrderStatus.SEWING -> OrderStatus.READY
                    OrderStatus.READY -> OrderStatus.DELIVERED
                    OrderStatus.DELIVERED -> null
                }

                if (nextStatus != null) {
                    Button(
                        onClick = { onNextStatus(nextStatus) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (nextStatus == OrderStatus.READY) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("تحويل لـ: ${nextStatus.titleAr}", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private val abs = { n: Int -> if (n < 0) -n else n }
