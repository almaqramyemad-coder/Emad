package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Voucher
import com.example.data.viewmodel.TailorViewModel
import com.example.ui.theme.GoldAccent
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReportsScreen(
    viewModel: TailorViewModel,
    orders: List<Order>,
    customers: List<Customer>,
    vouchers: List<Voucher>
) {
    val shopSettings by viewModel.shopSettings.collectAsState()
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

    // Analytics calculations
    val totalRevenue = orders.sumOf { it.totalAmount }
    val totalPaid = orders.sumOf { it.paidAmount }
    val totalRemaining = orders.sumOf { it.remainingAmount }
    val totalVat = orders.sumOf { it.taxAmount }
    val averageOrderValue = if (orders.isNotEmpty()) totalRevenue / orders.size else 0.0

    val newOrdersCount = orders.count { it.status == OrderStatus.NEW }
    val cuttingOrdersCount = orders.count { it.status == OrderStatus.CUTTING }
    val sewingOrdersCount = orders.count { it.status == OrderStatus.SEWING }
    val readyOrdersCount = orders.count { it.status == OrderStatus.READY }
    val deliveredOrdersCount = orders.count { it.status == OrderStatus.DELIVERED }

    var selectedPeriod by remember { mutableStateOf("الكل") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("reports_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Header Title Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "تقارير وتحليلات المبيعات",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = shopSettings.shopName,
                                fontSize = 13.sp,
                                color = Color.LightGray
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(GoldAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.BarChart, contentDescription = null, tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تاريخ التقرير: ${dateFormat.format(Date())}",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("الكل", "هذا الشهر", "هذا الأسبوع").forEach { period ->
                                FilterChip(
                                    selected = selectedPeriod == period,
                                    onClick = { selectedPeriod = period },
                                    label = { Text(period, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = GoldAccent,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Financial KPI Highlights
        item {
            Text(
                text = "الملخص المالي العام",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ReportStatCard(
                        title = "إجمالي المبيعات",
                        value = "${String.format(Locale.US, "%.2f", totalRevenue)} ر.س",
                        subtitle = "${orders.size} فاتورة مسجلة",
                        icon = Icons.Default.Payments,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    ReportStatCard(
                        title = "المبالغ المحصلة",
                        value = "${String.format(Locale.US, "%.2f", totalPaid)} ر.س",
                        subtitle = "دفعة نقداً وشبكة",
                        icon = Icons.Default.AccountBalanceWallet,
                        color = Color(0xFF16A34A),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ReportStatCard(
                        title = "الديون المتبقية",
                        value = "${String.format(Locale.US, "%.2f", totalRemaining)} ر.س",
                        subtitle = "تستحق عند الاستلام",
                        icon = Icons.Default.MoneyOff,
                        color = Color(0xFFDC2626),
                        modifier = Modifier.weight(1f)
                    )
                    ReportStatCard(
                        title = "ضريبة القيمة المضافة",
                        value = "${String.format(Locale.US, "%.2f", totalVat)} ر.س",
                        subtitle = "بنسبة ${shopSettings.vatRatePercent}%",
                        icon = Icons.Default.Receipt,
                        color = GoldAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Order Status Progress Distribution
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "توزيع حالات الطلبات في المفرش/الورود",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    StatusProgressBar("جديد (في الانتظار)", newOrdersCount, orders.size, Color(0xFF3B82F6))
                    StatusProgressBar("قيد القص والتقطيع", cuttingOrdersCount, orders.size, Color(0xFFF59E0B))
                    StatusProgressBar("قيد الخياطة والتركيب", sewingOrdersCount, orders.size, Color(0xFF8B5CF6))
                    StatusProgressBar("جاهز للتسليم بالمعرض", readyOrdersCount, orders.size, Color(0xFF10B981))
                    StatusProgressBar("تم التسليم للعميل", deliveredOrdersCount, orders.size, Color(0xFF6B7280))
                }
            }
        }

        // Customer & Operational Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "مؤشرات العملاء والأداء",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إجمالي العملاء المسجلين بالمحل:", fontSize = 13.sp, color = Color.DarkGray)
                        Text("${customers.size} عميل", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("متوسط قيمة الفاتورة الواحدة:", fontSize = 13.sp, color = Color.DarkGray)
                        Text("${String.format(Locale.US, "%.2f", averageOrderValue)} ر.س", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إجمالي عدد السندات المالية الصادرة:", fontSize = 13.sp, color = Color.DarkGray)
                        Text("${vouchers.size} سند", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ReportStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A))
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
            Text(text = subtitle, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun StatusProgressBar(
    label: String,
    count: Int,
    total: Int,
    color: Color
) {
    val progress = if (total > 0) count.toFloat() / total.toFloat() else 0f

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E293B))
            Text(text = "$count ($String.format(Locale.US, \"%.0f\", progress * 100)%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.15f)
        )
    }
}
