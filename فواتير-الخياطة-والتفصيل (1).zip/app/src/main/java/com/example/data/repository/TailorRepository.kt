package com.example.data.repository

import com.example.data.dao.CustomerDao
import com.example.data.dao.MeasurementDao
import com.example.data.dao.OrderDao
import com.example.data.dao.VoucherDao
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class TailorRepository(
    private val customerDao: CustomerDao,
    private val measurementDao: MeasurementDao,
    private val orderDao: OrderDao,
    private val voucherDao: VoucherDao? = null
) {
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()
    val allVouchers: Flow<List<Voucher>> = voucherDao?.getAllVouchers() ?: emptyFlow()

    fun searchCustomers(query: String): Flow<List<Customer>> = customerDao.searchCustomers(query)
    fun searchOrders(query: String): Flow<List<Order>> = orderDao.searchOrders(query)
    fun getOrdersByStatus(status: OrderStatus): Flow<List<Order>> = orderDao.getOrdersByStatus(status)
    fun getCustomerOrders(customerId: Long): Flow<List<Order>> = orderDao.getOrdersForCustomer(customerId)
    fun getCustomerLatestMeasurement(customerId: Long): Flow<Measurement?> = measurementDao.getLatestMeasurementForCustomer(customerId)
    fun getOrderItems(orderId: Long): Flow<List<OrderItem>> = orderDao.getOrderItems(orderId)
    fun getCustomerVouchers(customerId: Long): Flow<List<Voucher>> = voucherDao?.getVouchersForCustomer(customerId) ?: emptyFlow()

    suspend fun saveVoucher(voucher: Voucher): Long = voucherDao?.insertVoucher(voucher) ?: 0L
    suspend fun deleteVoucher(voucher: Voucher) { voucherDao?.deleteVoucher(voucher) }

    suspend fun getCustomerById(customerId: Long): Customer? = customerDao.getCustomerById(customerId)
    suspend fun getOrderById(orderId: Long): Order? = orderDao.getOrderById(orderId)
    suspend fun getOrderItemsDirect(orderId: Long): List<OrderItem> = orderDao.getOrderItemsDirect(orderId)
    suspend fun getLatestMeasurementDirect(customerId: Long): Measurement? = measurementDao.getLatestMeasurementDirect(customerId)

    suspend fun saveCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    suspend fun saveMeasurement(measurement: Measurement): Long = measurementDao.insertMeasurement(measurement)

    suspend fun createInvoice(
        order: Order,
        items: List<OrderItem>
    ): Long = withContext(Dispatchers.IO) {
        val orderId = orderDao.insertOrder(order)
        val itemsWithId = items.map { it.copy(orderId = orderId) }
        orderDao.insertOrderItems(itemsWithId)
        orderId
    }

    suspend fun updateOrderStatus(orderId: Long, newStatus: OrderStatus) {
        orderDao.updateOrderStatus(orderId, newStatus)
    }

    suspend fun updateOrder(order: Order) = orderDao.updateOrder(order)
    suspend fun deleteOrder(order: Order) = orderDao.deleteOrder(order)

    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val currentCustomers = customerDao.getAllCustomers().first()
        if (currentCustomers.isNotEmpty()) return@withContext

        // Seed Customers
        val c1Id = customerDao.insertCustomer(
            Customer(name = "سعود عبد العزيز الخالد", phone = "0501112233", city = "الرياض", notes = "عميل مميز - يفضل القماش الياباني")
        )
        val c2Id = customerDao.insertCustomer(
            Customer(name = "محمد بن فهد العتيبي", phone = "0554445566", city = "جدة", notes = "مستعجل دائماً - تطريز كويتي")
        )
        val c3Id = customerDao.insertCustomer(
            Customer(name = "عبد الله بن علي الشمري", phone = "0567778899", city = "الدمام", notes = "مقاسات خاصة للأكمام")
        )
        val c4Id = customerDao.insertCustomer(
            Customer(name = "خالد بن إبراهيم السلمان", phone = "0533334455", city = "الرياض", notes = "خياطة عادية")
        )

        // Seed Measurements
        measurementDao.insertMeasurement(
            Measurement(
                customerId = c1Id,
                length = 145.0, shoulder = 46.5, sleeve = 61.0, neck = 42.0,
                chest = 58.0, waist = 56.0, bottomWidth = 82.0, cuff = 14.5,
                collarType = "قلاب مربع", pocketType = "جيب مخفي", fabricType = "سلك ياباني ممتاز - أبيض",
                fitPreference = "ضيق / Slim Fit",
                sleeveAdjustment = "تطويل 1 سم (+1cm)",
                collarStyleDetail = "قلاب كويتي مقوى 2 سم",
                shoulderType = "كتف مائل / Slanted",
                buttonStyle = "أزرار مخفية",
                customPreferences = "تكسير الجانبين، جيب جوال داخلي وسيع",
                notes = "فتحة السحاب 35 سم"
            )
        )

        measurementDao.insertMeasurement(
            Measurement(
                customerId = c2Id,
                length = 148.0, shoulder = 48.0, sleeve = 63.5, neck = 43.5,
                chest = 60.0, waist = 58.0, bottomWidth = 85.0, cuff = 15.0,
                collarType = "قلاب دائري", pocketType = "جيب خارجي مبروم", fabricType = "قطن مكس كريمي",
                fitPreference = "عادي / Regular",
                sleeveAdjustment = "بدون تعديل (قياسي)",
                collarStyleDetail = "قلاب سعودي سادة",
                shoulderType = "طبيعي / Natural",
                buttonStyle = "أزرار خشبية 3 حبات",
                customPreferences = "توسيع فتحة الإبط 1 سم",
                notes = "كبك عادي مع زرار خشبي"
            )
        )

        measurementDao.insertMeasurement(
            Measurement(
                customerId = c3Id,
                length = 142.0, shoulder = 45.0, sleeve = 60.0, neck = 41.0,
                chest = 55.0, waist = 53.0, bottomWidth = 78.0, cuff = 14.0,
                collarType = "قلاب سادة", pocketType = "جيب مخفي + جيب جوال", fabricType = "سميراميس فاخر",
                fitPreference = "رسمي / Classic",
                sleeveAdjustment = "تقصير 1 سم (-1cm)",
                collarStyleDetail = "ياقة رسمية مع أزرار",
                shoulderType = "مع حشوة اسفنج / Padded",
                buttonStyle = "أزرار صدفي ظاهرة",
                customPreferences = "خياطة مزدوجة على الكتف",
                notes = "تقصير طول الكم 0.5 سم"
            )
        )

        measurementDao.insertMeasurement(
            Measurement(
                customerId = c4Id,
                length = 140.0, shoulder = 44.0, sleeve = 59.0, neck = 40.5,
                chest = 54.0, waist = 52.0, bottomWidth = 76.0, cuff = 13.5,
                collarType = "قلاب مربع", pocketType = "جيب عادي", fabricType = "قماش ربيعي خفيف",
                fitPreference = "وسيع / Loose",
                sleeveAdjustment = "بدون تعديل (قياسي)",
                collarStyleDetail = "قلاب عادي لين",
                shoulderType = "طبيعي / Natural",
                buttonStyle = "أزرار مخفية",
                customPreferences = "كسرة ظهر خفيفة"
            )
        )

        // Dates relative to current time
        val now = System.currentTimeMillis()
        val oneDay = 86400000L

        // Order 1: Cutting
        val o1Id = orderDao.insertOrder(
            Order(
                orderNumber = "INV-2026-001",
                customerId = c1Id,
                customerName = "سعود عبد العزيز الخالد",
                customerPhone = "0501112233",
                orderDate = now - (oneDay * 2),
                deliveryDate = now + (oneDay * 3),
                status = OrderStatus.CUTTING,
                subtotal = 750.0,
                discount = 50.0,
                taxAmount = 105.0,
                totalAmount = 805.0,
                paidAmount = 400.0,
                remainingAmount = 405.0,
                paymentMethod = "شبكة مدى",
                notes = "تسليم قبل عطلة نهاية الأسبوع"
            )
        )
        orderDao.insertOrderItems(
            listOf(
                OrderItem(orderId = o1Id, itemType = "ثوب كويتي فاخر", quantity = 3, unitPrice = 250.0, fabricDetails = "سلك ياباني ممتاز")
            )
        )

        // Order 2: Sewing (Urgent tomorrow!)
        val o2Id = orderDao.insertOrder(
            Order(
                orderNumber = "INV-2026-002",
                customerId = c2Id,
                customerName = "محمد بن فهد العتيبي",
                customerPhone = "0554445566",
                orderDate = now - (oneDay * 1),
                deliveryDate = now + (oneDay * 1),
                status = OrderStatus.SEWING,
                subtotal = 600.0,
                discount = 0.0,
                taxAmount = 90.0,
                totalAmount = 690.0,
                paidAmount = 690.0,
                remainingAmount = 0.0,
                paymentMethod = "كاش",
                notes = "مستعجل جداً"
            )
        )
        orderDao.insertOrderItems(
            listOf(
                OrderItem(orderId = o2Id, itemType = "ثوب سعودي مطرز", quantity = 2, unitPrice = 300.0, fabricDetails = "قطن مكس كريمي")
            )
        )

        // Order 3: Ready for Pickup
        val o3Id = orderDao.insertOrder(
            Order(
                orderNumber = "INV-2026-003",
                customerId = c3Id,
                customerName = "عبد الله بن علي الشمري",
                customerPhone = "0567778899",
                orderDate = now - (oneDay * 4),
                deliveryDate = now,
                status = OrderStatus.READY,
                subtotal = 550.0,
                discount = 20.0,
                taxAmount = 79.50,
                totalAmount = 609.50,
                paidAmount = 300.0,
                remainingAmount = 309.50,
                paymentMethod = "تحويل بنكي",
                notes = "جاهز في المعرض"
            )
        )
        orderDao.insertOrderItems(
            listOf(
                OrderItem(orderId = o3Id, itemType = "ثوب قطري", quantity = 1, unitPrice = 250.0, fabricDetails = "سميراميس فاخر"),
                OrderItem(orderId = o3Id, itemType = "دقلة مناسبات", quantity = 1, unitPrice = 300.0, fabricDetails = "تطريز خاص")
            )
        )

        // Order 4: Delivered
        val o4Id = orderDao.insertOrder(
            Order(
                orderNumber = "INV-2026-004",
                customerId = c4Id,
                customerName = "خالد بن إبراهيم السلمان",
                customerPhone = "0533334455",
                orderDate = now - (oneDay * 7),
                deliveryDate = now - (oneDay * 2),
                status = OrderStatus.DELIVERED,
                subtotal = 400.0,
                discount = 0.0,
                taxAmount = 60.0,
                totalAmount = 460.0,
                paidAmount = 460.0,
                remainingAmount = 0.0,
                paymentMethod = "شبكة مدى",
                notes = "تم الاستلام بنجاح"
            )
        )
        orderDao.insertOrderItems(
            listOf(
                OrderItem(orderId = o4Id, itemType = "ثوب عادي", quantity = 2, unitPrice = 200.0, fabricDetails = "قماش ربيعي")
            )
        )
    }
}
