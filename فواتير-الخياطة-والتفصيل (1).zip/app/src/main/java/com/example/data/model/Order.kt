package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderNumber: String,          // رقم الفاتورة: INV-1001
    val customerId: Long,
    val customerName: String,
    val customerPhone: String,
    val orderDate: Long = System.currentTimeMillis(),
    val deliveryDate: Long,
    val status: OrderStatus = OrderStatus.NEW,
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val totalAmount: Double = 0.0,    // الصافي الإجمالي
    val paidAmount: Double = 0.0,     // العربون / المدفوع
    val remainingAmount: Double = 0.0, // المتبقي
    val paymentMethod: String = "كاش", // كاش / شبكة مدى / تحويل
    val notes: String = ""
)
