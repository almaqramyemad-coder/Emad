package com.example.data.model

data class ShopSettings(
    val shopName: String = "خياطة الأناقة والرفاهية",
    val phone: String = "0501234567",
    val crNumber: String = "1010987654",         // السجل التجاري
    val taxNumber: String = "310123456700003",    // الرقم الضريبي
    val address: String = "الرياض - طريق الملك فهد",
    val vatRatePercent: Double = 15.0,
    val invoiceTerms: String = "شكراً لزيارتكم. يرجى إحضار سند الفاتورة عند الاستلام. التعديلات متاحة خلال 7 أيام من الاستلام."
)
