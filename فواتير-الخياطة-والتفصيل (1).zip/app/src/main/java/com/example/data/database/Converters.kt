package com.example.data.database

import androidx.room.TypeConverter
import com.example.data.model.OrderStatus
import com.example.data.model.VoucherType

class Converters {
    @TypeConverter
    fun fromOrderStatus(value: OrderStatus): String {
        return value.name
    }

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus {
        return try {
            OrderStatus.valueOf(value)
        } catch (e: Exception) {
            OrderStatus.NEW
        }
    }

    @TypeConverter
    fun fromVoucherType(value: VoucherType): String {
        return value.name
    }

    @TypeConverter
    fun toVoucherType(value: String): VoucherType {
        return try {
            VoucherType.valueOf(value)
        } catch (e: Exception) {
            VoucherType.RECEIPT
        }
    }
}

