package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "order_items")
data class OrderItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: Long,
    val itemType: String,       // ثوب سعودي، ثوب كويتي، دقلة، تعديل، فستان
    val quantity: Int = 1,
    val unitPrice: Double = 0.0,
    val fabricDetails: String = "",
    val notes: String = ""
)
