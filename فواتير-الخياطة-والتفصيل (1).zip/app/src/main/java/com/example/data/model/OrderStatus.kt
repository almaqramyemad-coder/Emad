package com.example.data.model

enum class OrderStatus(val titleAr: String) {
    NEW("جديد"),
    CUTTING("قيد القص"),
    SEWING("قيد الخياطة"),
    READY("جاهز للتسليم"),
    DELIVERED("تم التسليم");

    companion object {
        fun fromTitle(title: String): OrderStatus {
            return entries.firstOrNull { it.titleAr == title } ?: NEW
        }
    }
}
