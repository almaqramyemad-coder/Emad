package com.example.data.dao

import androidx.room.*
import com.example.data.model.Measurement
import kotlinx.coroutines.flow.Flow

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY updatedAt DESC LIMIT 1")
    fun getLatestMeasurementForCustomer(customerId: Long): Flow<Measurement?>

    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getLatestMeasurementDirect(customerId: Long): Measurement?

    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY updatedAt DESC")
    fun getMeasurementHistory(customerId: Long): Flow<List<Measurement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: Measurement): Long

    @Update
    suspend fun updateMeasurement(measurement: Measurement)
}
