package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "measurements")
data class Measurement(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val length: Double = 0.0,       // الطول الكلي
    val shoulder: Double = 0.0,     // الكتف
    val sleeve: Double = 0.0,       // طول الكم/اليد
    val neck: Double = 0.0,         // الرقبة
    val chest: Double = 0.0,        // الصدر
    val waist: Double = 0.0,        // الخصر
    val bottomWidth: Double = 0.0,  // وسع الأسفل
    val cuff: Double = 0.0,         // الكبك/الأسورة
    val collarType: String = "قلاب مربع",   // نوع القلاب الرئيسي
    val pocketType: String = "جيب مخفي",    // نوع الجيب
    val fabricType: String = "سلك ياباني فاخر",  // نوع القماش
    val fitPreference: String = "عادي / Regular", // نوع القَصّة (ضيق، عادي، وسيع، رسمي)
    val sleeveAdjustment: String = "بدون تعديل (قياسي)", // تعديلات طول الكم/اليد
    val collarStyleDetail: String = "قلاب كويتي مقوى", // تفاصيل وتصلّب القلاب
    val shoulderType: String = "طبيعي / Natural", // نوع الكتف (طبيعي، مائل، اسفنج)
    val buttonStyle: String = "أزرار مخفية", // نوع وتصميم الأزرار
    val customPreferences: String = "", // تفضيلات وتوصيات تفصيل خاصة مخصصة
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
