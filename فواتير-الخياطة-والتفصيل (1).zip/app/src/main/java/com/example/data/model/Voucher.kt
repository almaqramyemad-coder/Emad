package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VoucherType(val title: String) {
    RECEIPT("سند قبض"),
    PAYMENT("سند صرف")
}

@Entity(tableName = "vouchers")
data class Voucher(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val voucherNumber: String,
    val voucherType: VoucherType,
    val customerId: Long? = null,
    val customerName: String,
    val orderId: Long? = null,
    val amount: Double,
    val paymentMethod: String = "نقداً",
    val description: String,
    val date: Long = System.currentTimeMillis()
)
