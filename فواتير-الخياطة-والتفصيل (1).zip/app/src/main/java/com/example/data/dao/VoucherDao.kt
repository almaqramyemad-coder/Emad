package com.example.data.dao

import androidx.room.*
import com.example.data.model.Voucher
import kotlinx.coroutines.flow.Flow

@Dao
interface VoucherDao {
    @Query("SELECT * FROM vouchers ORDER BY date DESC")
    fun getAllVouchers(): Flow<List<Voucher>>

    @Query("SELECT * FROM vouchers WHERE id = :id")
    suspend fun getVoucherById(id: Long): Voucher?

    @Query("SELECT * FROM vouchers WHERE customerId = :customerId ORDER BY date DESC")
    fun getVouchersForCustomer(customerId: Long): Flow<List<Voucher>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoucher(voucher: Voucher): Long

    @Delete
    suspend fun deleteVoucher(voucher: Voucher)
}
